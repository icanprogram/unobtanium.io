Unobtanium 0.9.0 [Un]

Proof of Work SHA256D Cryptocurrency based on Bitcoin 0.8.99

3 Minute Block targets 

Fast, progressive (4 blocks over 80) difficulty adjustments of max 10% up/20% down

First 2000 Blocks = subsidy of .001 coins

After 2000 Blocks = 1 Coin per block, halving every 102,000 Blocks

Minimum subsidy of .00001 coin after final halving at 612,000 Blocks
 
250,000 Max Coins Ever, ~190K-ish for block halving + 60K-ish for long term mining

RPC Port = 65535

P2P Port = 65534
